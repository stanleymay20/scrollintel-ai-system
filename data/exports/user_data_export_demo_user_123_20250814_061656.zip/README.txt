
ScrollIntel Data Export
======================

Export Date: 2025-08-14T06:16:56.168783
User ID: demo_user_123

This archive contains all personal data associated with your ScrollIntel account:

- profile.json: Your account profile information
- consents.json: Your consent preferences and history
- activity_logs.json: Your platform activity logs
- files_metadata.json: Metadata about files you've uploaded

This export complies with GDPR Article 20 (Right to Data Portability).

For questions about this export, please contact support@scrollintel.com
